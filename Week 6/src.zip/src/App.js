import logo from './logo.svg';
import './App.css';

function App() {
  return (
    <h1>Welcome to your first react</h1>
  );
}

export default App;

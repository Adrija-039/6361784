// src/Components/Contact.js
import React from 'react';

function Contact() {
  return (
    <div>
      <h2>Welcome to the Contact page of the Student Management Portal</h2>
    </div>
  );
}

export default Contact;

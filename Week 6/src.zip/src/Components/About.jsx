// src/Components/About.js
import React from 'react';

function About() {
  return (
    <div>
      <h2>Welcome to the About page of the Student Management Portal</h2>
    </div>
  );
}

export default About;
